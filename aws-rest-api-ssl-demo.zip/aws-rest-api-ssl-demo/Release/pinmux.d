# FIXED

pinmux.obj: ../pinmux.c
pinmux.obj: ../pinmux.h
pinmux.obj: C:/ti/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h
pinmux.obj: C:/ti/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h
pinmux.obj: C:/ti/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h
pinmux.obj: C:/ti/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h
pinmux.obj: C:/ti/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h
pinmux.obj: C:/ti/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h

../pinmux.c: 
../pinmux.h: 
C:/ti/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_types.h: 
C:/ti/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_memmap.h: 
C:/ti/CC3200SDK_1.4.0/cc3200-sdk/inc/hw_gpio.h: 
C:/ti/CC3200SDK_1.4.0/cc3200-sdk/driverlib/pin.h: 
C:/ti/CC3200SDK_1.4.0/cc3200-sdk/driverlib/gpio.h: 
C:/ti/CC3200SDK_1.4.0/cc3200-sdk/driverlib/prcm.h: 
